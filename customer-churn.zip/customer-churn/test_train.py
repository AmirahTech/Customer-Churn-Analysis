from src.train import train_model

# Train the model
model = train_model("data/WA_Fn-UseC_-Telco-Customer-Churn.csv")
print("Training completed successfully!")
